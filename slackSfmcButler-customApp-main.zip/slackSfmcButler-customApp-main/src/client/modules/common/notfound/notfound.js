import { LightningElement } from 'lwc';

export default class NotFound extends LightningElement {}
