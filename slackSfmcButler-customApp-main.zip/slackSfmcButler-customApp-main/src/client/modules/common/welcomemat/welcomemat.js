import { LightningElement } from 'lwc';

export default class WelcomeMat extends LightningElement {}
