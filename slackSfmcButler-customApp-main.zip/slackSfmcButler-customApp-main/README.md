# sfmc2slack

## TODOs

-   Complete Replication logic
-   build calculations
-   build outbound messaging to slack
-   build scheduling logic
-   build UI compotents
